#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "shader.h"
#include "camera.h"
#include "basic_camera.h"
#include "pointLight.h"
#include "directionalLight.h"
#include "SpotLight.h"
#include "bench.h"
#include "swing.h"
#include "stand.h"
#include "cube.h"
#include "stb_image.h"
#include <iostream>
#include "sphere.h"
#include "drawcube.h"
#include "cone.h"
#include "coneWithTexture.h"
#include "hexagon.h"
#include "HalfSphere.h"
#include "curve.h"

struct Point {
    float x;
    float y;
    float z;
};
std::vector<float>cXALL;
std::vector<float>cZALL;
float cRALL = 6.5;

int kp1 = 0;
int kp3 = 0;
int kp4 = 0;
int kp5 = 0;
int flagDOLNA = 0;


std::vector<float>cX2;
std::vector<float>cZ2;
float cR2 = 6;
float dseatheta = 0.0;
int flagsd = -2;
int flagsd1 = -2;
float dseatheta100 = 0.0;
float dxxtamim = 0.0;
float dyytamim = 0.0;


float rtheta = 0.0;
using namespace std;

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
unsigned int loadTexture(char const* path, GLenum textureWrappingModeS, GLenum textureWrappingModeT, GLenum textureFilteringModeMin, GLenum textureFilteringModeMax);
void processInput(GLFWwindow* window);
void stall1(unsigned int& cubeVAO, Cube& coffee, Cube& coffee1, Cube& coffee2, Shader& lightingShader, Shader& lightingShaderWithTexture, float txC, float tyC, float tzC);
void drawTreeWithFractiles(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N);
void drawTreeWithFractiles1(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N);
void drawTreeWithFractiles2(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N);
void drawTreeWithFractiles3(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N);
//void drawCylindricalTree(BezierCurve& CylinderGreen, BezierCurve& CylinderGrey, Shader& lightingShader, glm::mat4 alTogether);
//void drawNormalTree(BezierCurve& NormalTree, BezierCurve& CylinderGrey, Shader& lightingShader, glm::mat4 alTogether);
//void drawTrees(BezierCurve& NormalTree, BezierCurve& CylinderGreen, BezierCurve& CylinderGrey, Shader& lightingShader, glm::mat4 alTogether);




glm::mat4 transform(float tr_x, float tr_y, float tr_z, float rot_x, float rot_y, float rot_z, float scal_x, float scal_y, float scal_z) {
    // Modelling Transformation
    glm::mat4 identityMatrix = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
    glm::mat4 translateMatrix, rotateXMatrix, rotateYMatrix, rotateZMatrix, scaleMatrix, model;
    translateMatrix = glm::translate(identityMatrix, glm::vec3(tr_x, tr_y, tr_z));
    rotateXMatrix = glm::rotate(identityMatrix, glm::radians(rot_x), glm::vec3(1.0f, 0.0f, 0.0f));
    rotateYMatrix = glm::rotate(identityMatrix, glm::radians(rot_y), glm::vec3(0.0f, 1.0f, 0.0f));
    rotateZMatrix = glm::rotate(identityMatrix, glm::radians(rot_z), glm::vec3(0.0f, 0.0f, 1.0f));
    scaleMatrix = glm::scale(identityMatrix, glm::vec3(scal_x, scal_y, scal_z));
    model = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
    return model;
}
// settings
const unsigned int SCR_WIDTH = 1800;
const unsigned int SCR_HEIGHT = 1000;

// modelling transform
float rotateAngle_X = 0.0;
float rotateAngle_Y = 0.0;
float rotateAngle_Z = 0.0;
float rotateAxis_X = 0.0;
float rotateAxis_Y = 0.0;
float rotateAxis_Z = 1.0;
float translate_X = 0.0;
float translate_Y = 0.0;
float translate_Z = 0.0;
float scale_X = 1.0;
float scale_Y = 1.0;
float scale_Z = 1.0;
float dx = 0.000;
int  flag = 4;
int nightflag = 1;
int flagSD = 4;
float dy = 0.0000;
float dxx = 0.0000;
float dtheta = 0.0;
float dthetaY = 0.0;
int flagSeeSaw = 1;
float dtheta12 = 0.0;
int flagR = 0;
float dyL = 0.0;
int flagNagordola = 0;
int Ni = 0;
int tiTest = 0;
int flagTest = 1;
int flagRocket = 0;
float dthetaX = 0.0;
int rocketI = 0;
int rt = 899;
int rti = 1799;
int rtii = 2699;
int rtiii = 3599;
int di = 599;
int dii = 1199;
int diii = 1799;
int diiv = 2399;
int dv = 2999;
int dvi = 3599;


int tiii = 3599;
int tii = 2699;
int ti = 1799;
int t = 899;
float irt = 0.0;
float irtz = 0.0;

vector <float> coordinates;
vector <float> normals;
vector <int> indices;
vector <float> vertices;
class point
{
public:
    point()
    {
        x = 0;
        y = 0;
    }
    int x;
    int y;
} clkpt[2];
int mouseButtonFlag = 0;
FILE* fp;
const double pi = 3.14159265389;
const int nt = 40;
const int ntheta = 20;
bool showControlPoints = true;
bool loadBezierCurvePoints = false;
bool showHollowBezier = false;
bool lineMode = false;
unsigned int bezierVAO;
unsigned int bezierCylinderVAO;
unsigned int bezierForNagordola;
unsigned int bezierTree;
unsigned int bezierCyCurve;
unsigned int bezierMatha;
unsigned int bezierDolna;

// camera
Camera camera(glm::vec3(-10.5f+25, 16.15f, -6.6 + 0.25f + 60.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

float eyeX = 0.0, eyeY = 1.0, eyeZ = 3.0;
float lookAtX = 0.0, lookAtY = 0.0, lookAtZ = 0.0;
glm::vec3 V = glm::vec3(0.0f, 1.0f, 0.0f);


// positions of the point lights

glm::vec3 pointLightPositions[] = {
    glm::vec3(7.0f,5.0f,10.0f),//ok done 
    glm::vec3(45.0f,5.0f,10.0f),
    glm::vec3(90.0f,  54.0f,   10.0f),
    glm::vec3(-33.0f, 54.6f, -20.8),//ok done
    
};

PointLight pointlight1(

    pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z,  // position
        // ambient
    0.05f, 0.05f, 0.05f,     // ambient
    0.8f, 0.8f, 0.8f,     // diffuse
    1.0f, 1.0f, 1.0f,        // specular
    1.0f,   //k_c
    0.014f,  //k_l
    0.0007, //k_q
    1       // light number
);

PointLight pointlight3(

    pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z,  // position
    0.05f, 0.05f, 0.05f,     // ambient
    0.8f, 0.8f, 0.8f,     // diffuse
    1.0f, 1.0f, 1.0f,        // specular
    1.0f,   //k_c
    0.014f,  //k_l
    0.0007, //k_q
    2       // light number
);



PointLight pointlight4(

    pointLightPositions[2].x, pointLightPositions[2].y, pointLightPositions[2].z,  // position
    0.05f, 0.05f, 0.05f,     // ambient
    0.8f, 0.8f, 0.8f,     // diffuse
    1.0f, 1.0f, 1.0f,        // specular
    1.0f,   //k_c
    0.014f,  //k_l
    0.0007, //k_q
    3       // light number
);
PointLight pointlight5(

    pointLightPositions[3].x, pointLightPositions[3].y, pointLightPositions[3].z,  // position
    0.05f, 0.05f, 0.05f,     // ambient
    0.8f, 0.8f, 0.8f,     // diffuse
    1.0f, 1.0f, 1.0f,        // specular
    1.0f,   //k_c
    0.014f,  //k_l
    0.0007, //k_q
    4       // light number
);



DirLight dirLight(
        -0.2f, -1.0f, -0.3f,
        0.05f, 0.05f, 0.05f,
        .5f, 0.5f, 0.5f,     // diffuse
        0.5f, 0.5f, 0.5f
);


SpotLight spotLight(
    -3.50f, 4.0f, -2.0f,
    0.6f, -1.0f, 0.5f,
    0.5f, 0.0f, 0.5f,
    1.0f, 0.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f,
    0.09f,
    0.032f,
    12.5f,
    15.0f
);





// light settings
bool PointToggle1 = true;
bool PointToggle3 = true;
bool PointToggle4 = true;
bool ambientToggle = true;
bool diffuseToggle = true;
bool specularToggle = true;


// timing
float deltaTime = 1.5f;    // time between current frame and last frame
float lastFrame = 0.0f;


int main()
{
    cout << "Day: O" << endl;
    cout << "Night: P" << endl;
    cout << "Birds and Rocket: M" << endl;
    cout << "Lights: 3,4,7,8,9,0" << endl;
    cout << "Others: Q,S,A,D,X,R etc." << endl;
    int ti = 0;
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "CSE 4208: Computer Graphics Laboratory", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // configure global opengl state
    // -----------------------------
    glEnable(GL_DEPTH_TEST);

    // build and compile our shader zprogram
    // ------------------------------------
    Shader lightingShader("vertexShaderForPhongShading.vs", "fragmentShaderForPhongShading.fs");
    //Shader lightingShader("vertexShaderForPhongShadingWithTexture.vs", "fragmentShaderForPhongShadingWithTexture.fs");
    
    //Shader lightingShader("vertexShaderForGouraudShading.vs", "fragmentShaderForGouraudShading.fs");
    Shader ourShader("vertexShader.vs", "fragmentShader.fs");

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    

    float cube_vertices[] = {
        // positions      // normals
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f,
        1.0f, 1.0f, 0.0f, 0.0f, 0.0f, -1.0f, //back side of cube, surface normal on -z 
        0.0f, 1.0f, 0.0f, 0.0f, 0.0f, -1.0f,

        1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
        1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, //
        1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f,
        1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,

        0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f,

        0.0f, 0.0f, 1.0f, -1.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 1.0f, -1.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, -1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,

        1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f,
        1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f,

        0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f,
        1.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f,
        1.0f, 0.0f, 1.0f, 0.0f, -1.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f, -1.0f, 0.0f
    };
    unsigned int cube_indices[] = {
        0, 3, 2,
        2, 1, 0,

        4, 5, 7,
        7, 6, 4,

        8, 9, 10,
        10, 11, 8,

        12, 13, 14,
        14, 15, 12,

        16, 17, 18,
        18, 19, 16,

        20, 21, 22,
        22, 23, 20
    };

    unsigned int cubeVAO, cubeVBO, cubeEBO; 
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glGenBuffers(1, &cubeEBO);

    glBindVertexArray(cubeVAO); 

    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cube_vertices), cube_vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cube_indices), cube_indices, GL_STATIC_DRAW);


    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // vertex normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)12);
    glEnableVertexAttribArray(1);

    // second, configure the light's VAO (VBO stays the same; the vertices are the same for the light object which is also a 3D cube)
    unsigned int lightCubeVAO;
    glGenVertexArrays(1, &lightCubeVAO);
    glBindVertexArray(lightCubeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO);
    // note that we update the lamp's position attribute's stride to reflect the updated buffer data
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    //cylinder sd points
    std::vector<Point> cylinder;
    //cylinder.push_back({ 0, 0, -8 });
    float radius1 = 2.0;
    float radius = 1.5;
    for (float theta = 0; theta <= 360; theta += 1) {
        float x = radius * glm::cos(glm::radians(theta));
        float y = radius * glm::sin(glm::radians(theta));

        float x1 = radius1 * glm::cos(glm::radians(theta));
        float y1 = radius1 * glm::sin(glm::radians(theta));

        cylinder.push_back({ x, y, 0.0f });
        cylinder.push_back({ x1, y1, -2.0f }); // normal cylinder
        //cylinder.push_back({ x * .5f, y * .5f, -8.0f }); // cylinder with different circle radius
    }

    unsigned int CVBO, CVAO;
    glGenVertexArrays(1, &CVAO);
    glGenBuffers(1, &CVBO);

    glBindVertexArray(CVAO);

    glBindBuffer(GL_ARRAY_BUFFER, CVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(struct Point) * cylinder.size(), cylinder.data(), GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(struct Point), (void*)0);
    glEnableVertexAttribArray(0);
    //end of sd cylinder point

    //CYLINDER CIRCLE POINTS START
    std::vector<Point> cylindercircle;
    cylindercircle.push_back({ 0, 0, -8 });
    float radiusC = 6.0;
    //float radius = 1.0;
    for (float theta = 0; theta <= 360; theta += 1) {
        float x = radiusC * glm::cos(glm::radians(theta));
        float y = radiusC * glm::sin(glm::radians(theta));

        //float x1 = radius1 * glm::cos(glm::radians(theta));
        //float y1 = radius1 * glm::sin(glm::radians(theta));

        cylindercircle.push_back({ x, y, -8.0f });
        //cylinder.push_back({ x1, y1, -2.0f }); // normal cylinder
        //cylinder.push_back({ x * .5f, y * .5f, -8.0f }); // cylinder with different circle radius
    }

    unsigned int CcVBO, CcVAO;
    glGenVertexArrays(1, &CcVAO);
    glGenBuffers(1, &CcVBO);

    glBindVertexArray(CcVAO);

    glBindBuffer(GL_ARRAY_BUFFER, CcVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(struct Point) * cylindercircle.size(), cylindercircle.data(), GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(struct Point), (void*)0);
    glEnableVertexAttribArray(0);
    //end of sd cylinderCIRCLE point







    // cylinder maku points start
    std::vector<Point> cylinderMaku;
    cylinderMaku.push_back({ 0, 0, -15 });
    float radiusM = 6.0;
    //float radius = 1.0;
    for (float theta = 0; theta <= 360; theta += 1) {
        float x = radiusM * glm::cos(glm::radians(theta));
        float y = radiusM * glm::sin(glm::radians(theta));

        //float x1 = radius1 * glm::cos(glm::radians(theta));
        //float y1 = radius1 * glm::sin(glm::radians(theta));

        cylinderMaku.push_back({ x, y, -8.0f });
        //cylinder.push_back({ x1, y1, -2.0f }); // normal cylinder
        //cylinder.push_back({ x * .5f, y * .5f, -8.0f }); // cylinder with different circle radius
    }

    unsigned int CMVBO, CMVAO;
    glGenVertexArrays(1, &CMVAO);
    glGenBuffers(1, &CMVBO);

    glBindVertexArray(CMVAO);

    glBindBuffer(GL_ARRAY_BUFFER, CMVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(struct Point) * cylinderMaku.size(), cylinderMaku.data(), GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(struct Point), (void*)0);
    glEnableVertexAttribArray(0);
    //end of sd cylinderMaku point


    //cylinder for rider shade
    std::vector<Point> cylinderShade;
    //cylinder.push_back({ 0, 0, -8 });
    float radiusSh = 3.0;
    for (float theta = 0; theta <= 360; theta += 1) {
        float x = radiusSh * glm::cos(glm::radians(theta));
        float y = radiusSh * glm::sin(glm::radians(theta));

        cylinderShade.push_back({ x, y, 0.0f });
        cylinderShade.push_back({ x, y, -2.0f }); // normal cylinder
        //cylinder.push_back({ x * .5f, y * .5f, -8.0f }); // cylinder with different circle radius
    }

    unsigned int CSVBO, CSVAO;
    glGenVertexArrays(1, &CSVAO);
    glGenBuffers(1, &CSVBO);

    glBindVertexArray(CSVAO);

    glBindBuffer(GL_ARRAY_BUFFER, CSVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(struct Point) * cylinderShade.size(), cylinderShade.data(), GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(struct Point), (void*)0);
    glEnableVertexAttribArray(0);




    Shader lightingShaderWithTexture("vertexShaderForPhongShadingWithTexture.vs", "fragmentShaderForPhongShadingWithTexture.fs");
    //Shader ourShader("vertexShader.vs", "fragmentShader.fs");
    string diffuseMapPath = "./container2.jpg";
    string specularMapPath = "./container2.jpg";
    string diffuseMapRoad = "./road.jpg";
    string specularMapRoad = "./road.jpg";
    string diffuseMapSky = "./sky.jpg";
    string specularMapSky = "./sky.jpg";
    string diffuseMapBrick = "./colr.jpg";
    string specularMapBrick = "./colr.jpg";
    string diffuseMapColor = "./color.jpg";
    string specularMapColor = "./color.jpg";
    string diffuseMapSofa = "./kong.jpg";
    string specularMapSofa = "./kong.jpg";
    string diffuseMapWater =  "./water.jpg";
    string specularMapWater = "./water.jpg";
    string diffuseMapCoffee = "./cffee1.jpg";
    string specularMapCoffee = "./cffee1.jpg";

    string diffuseMapCoffeeNes = "./nes.jpg";
    string specularMapCoffeeNes = "./nes.jpg";

    string diffuseMapCoffeeNes2 = "./tex.jpg";
    string specularMapCoffeeNes2 = "./tex.jpg";


    string diffuseMapWell = "./wel.png";
    string specularMapWell = "./wel.png";

    string diffuseMapWood = "./wood.jpg";
    string specularMapWood = "./wood.jpg";

    string diffuseMapF = "./laddu.png";
    string specularMapF = "./laddu.png";
    string diffuseMapFF = "./menu.png";
    string specularMapFF = "./menu.png";

    string diffuseMapp = "./pastry.png";
    string specularMapp = "./pastry.png";

    string diffuseMaps = "./glittery.jpg";
    string specularMaps = "./glittery.jpg";
    string diffuseMapss = "./home.jpg";
    string specularMapss = "./home.jpg";


    unsigned int diffMap = loadTexture(diffuseMapPath.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap = loadTexture(specularMapPath.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap1 = loadTexture(diffuseMapRoad.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap1 = loadTexture(specularMapRoad.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap2 = loadTexture(diffuseMapSky.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap2 = loadTexture(specularMapSky.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap3 = loadTexture(diffuseMapBrick.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap3 = loadTexture(specularMapBrick.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap4 = loadTexture(diffuseMapSofa.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap4 = loadTexture(specularMapSofa.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap5 = loadTexture(diffuseMapColor.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap5 = loadTexture(specularMapColor.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap6 = loadTexture(diffuseMapWater.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap6 = loadTexture(specularMapWater.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap7 = loadTexture(diffuseMapCoffee.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap7 = loadTexture(specularMapCoffee.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap8 = loadTexture(diffuseMapCoffeeNes2.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap8 = loadTexture(specularMapCoffeeNes2.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap9 = loadTexture(diffuseMapCoffeeNes.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap9 = loadTexture(specularMapCoffeeNes.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap10 = loadTexture(diffuseMapWell.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap10 = loadTexture(specularMapWell.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);

    unsigned int diffMap11 = loadTexture(diffuseMapWood.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap11 = loadTexture(specularMapWood.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);

    unsigned int diffMap12 = loadTexture(diffuseMapF.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap12 = loadTexture(specularMapF.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMap13 = loadTexture(diffuseMapFF.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMap13 = loadTexture(specularMapFF.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);

    unsigned int diffMapp = loadTexture(diffuseMapp.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMapp = loadTexture(specularMapp.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMaps = loadTexture(diffuseMaps.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMaps = loadTexture(specularMaps.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int diffMapmn = loadTexture(diffuseMapss.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int specMapmn = loadTexture(specularMapss.c_str(), GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);

    Cube road = Cube(diffMap1, specMap1, 32.0f, 0.0f, 0.0f, 2.0f, 2.0f);
    Cube water = Cube(diffMap6, specMap6, 32.0f, 0.0f, 0.0f, 100.0f, 100.0f);
    Cube brick = Cube(diffMap3, specMap3, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube sky = Cube(diffMap2, specMap2, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube sofa = Cube(diffMap4, specMap4, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube color = Cube(diffMap5, specMap5, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube coffee = Cube(diffMap7, specMap7, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube coffeeT = Cube(diffMap8, specMap8, 32.0f, 0.0f, 0.0f, 3.0f, 1.0f);
    Cube coffeT2 = Cube(diffMap9, specMap9, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube well = Cube(diffMap10, specMap10, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube menu = Cube(diffMap13, specMap13, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
    Cube menu2 = Cube(diffMapmn, specMapmn, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);

    Cube wood = Cube(diffMap11, specMap11, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);

    //std::cout << diffMap << ' ' << specMap << std::endl;
    Cube cube = Cube(diffMap, specMap, 32.0f, 0.0f, 0.0f, 20.0f, 20.0f);
    Cube cube1 = Cube();
    //Sphere sphere = Sphere(0.8);

    Cone cone = Cone();
    unsigned int coneMap = loadTexture("sky.jpg", GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
    unsigned int coneMap2 = loadTexture("kuet.png", GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);

    ConeWithTexture ghostTail(1.5f, 2.0, 50,
        glm::vec3(1.0f, 0.7f, 0.7f), // Ambient color 
        glm::vec3(1.0f, 0.7f, 0.7f),  // Diffuse color 
        glm::vec3(1.0f, 0.7f, 0.7f),  // Specular color 
        32.0f,                       // Shininess
        coneMap,              // Diffuse texture
        coneMap2              // Specular texture
    );


    Sphere1 sphere = Sphere1(diffMap11, specMap11, 0.0f, 0.0f, 4.0f, 4.0f);
    Sphere1 sphere1 = Sphere1(diffMaps, specMaps, 0.0f, 0.0f, 4.0f, 4.0f);


        // File paths for vertex and index data
        std::string vertexFile = "vertices.txt";
        std::string indexFile = "indices.txt";
        // Define material properties
        glm::vec3 ambient(0.5f, 0.5f, 0.5f); // Example ambient color
        glm::vec3 diffuse(0.7f, 0.7f, 0.7f); // Example diffuse color
        glm::vec3 specular(1.0f, 1.0f, 1.0f); // Example specular color
        float shininess = 64.0f;              // Example shininess
        glm::vec3 emission(0.3f, 0.3f, 0.3f); // Example emission color
        // Creating a Curve object
        Curve myCurve(vertexFile, indexFile, ambient, diffuse, specular, shininess, emission);



    HalfSphere hsphere = HalfSphere(diffMap12, specMap12, 1.0f, 1.0f, 1.0f, 1.0f);

    Hexagon hex = Hexagon(diffMapp, specMapp, 32.0f, 0.0f, 0.0f, 3.0f, 3.0f);
    Hexagon bash = Hexagon(diffMap7, specMap7, 32.0f, 0.0f, 0.0f, 3.0f, 3.0f);


    while (!glfwWindowShouldClose(window))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = static_cast<float>(glfwGetTime());
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.5294f, 0.8078f, 0.9804f, 0.05f);
        if (nightflag == 2)
        {
            glClearColor(0.0f,0.0f,0.2f, 0.1f);
            

        }
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // be sure to activate shader when setting uniforms/drawing objects
        lightingShader.use();
        lightingShader.setVec3("viewPos", camera.Position);
        // point light 1
        pointlight1.setUpPointLight(lightingShader);
        // point light 2
        //pointlight2.setUpPointLight(lightingShader);
        // point light 3
        pointlight3.setUpPointLight(lightingShader);
        // point light 4
        pointlight4.setUpPointLight(lightingShader);
        pointlight5.setUpPointLight(lightingShader);
        dirLight.setUpDirLight(lightingShader);
        spotLight.setUpSpotLight(lightingShader);
        lightingShader.use();


        // pass projection matrix to shader (note that in this case it could change every frame)
        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        //glm::mat4 projection = glm::ortho(-2.0f, +2.0f, -1.5f, +1.5f, 0.1f, 100.0f);
        lightingShader.setMat4("projection", projection);


        // Modelling Transformation
        glm::mat4 identityMatrix = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        glm::mat4 translateMatrix, rotateXMatrix, rotateYMatrix, rotateZMatrix, scaleMatrix, model;
        translateMatrix = glm::translate(identityMatrix, glm::vec3(translate_X, translate_Y, translate_Z));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(rotateAngle_X), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(rotateAngle_Y), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(rotateAngle_Z), glm::vec3(0.0f, 0.0f, 1.0f));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(scale_X, scale_Y, scale_Z));
        model = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        lightingShader.setMat4("model", model);
        glm::mat4 globalModel = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;




        // camera/view transformation
        float degree = 0;
        glm::mat4 view = camera.GetViewMatrix();
        float r = glm::length(camera.Position - glm::vec3(view[3]));
        ourShader.setMat4("view", view);
        ourShader.use();
        ourShader.setMat4("projection", projection);
        ourShader.setMat4("view", view);
        
        
        


        //;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

        // Car Body (using modelMaku1)
        glm::mat4 modelMaku1 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(18.0f, 2.8f+dx, -35.0f)); // Centered car body
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(0.0f, 0.0f, 1.0f)); // No rotation for body
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3f, 0.7f, 0.3f)); // Scaled to car body size
        modelMaku1 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku1);
        ourShader.setVec3("color", glm::vec3(1,0,0)); // Red color for car body
        ourShader.use();
        glBindVertexArray(CMVAO); // Assuming VAO for the car body
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 modelMaku1000 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(21.5f, 2.8f + dx, -35.0f)); // Centered car body
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(0.0f, 0.0f, 1.0f)); // No rotation for body
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3f, 0.7f, 0.3f)); // Scaled to car body size
        modelMaku1000 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku1000);
        ourShader.setVec3("color", glm::vec3(0,1,0)); // Red color for car body
        ourShader.use();
        glBindVertexArray(CMVAO); // Assuming VAO for the car body
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 modelMaku1001 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(14.5f, 2.8f + dx, -35.0f)); // Centered car body
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(0.0f, 0.0f, 1.0f)); // No rotation for body
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3f, 0.7f, 0.3f)); // Scaled to car body size
        modelMaku1001 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku1001);
        ourShader.setVec3("color", glm::vec3(0,0,1)); // Red color for car body
        ourShader.use();
        glBindVertexArray(CMVAO); // Assuming VAO for the car body
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());

        // Front Left Wheel (using model1)
        glm::mat4 model1 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(10.5f + dx,20.0f + dx, -20.8f )); // Position for front left wheel
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.5f, 0.5f, 1.0f)); // Rotate to align as a wheel
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1f, 0.1f, 0.1f)); // Scale for wheel size
        model1 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model1);
        ourShader.setVec3("color", glm::vec3(0.1f, 0.1f, 0.1f)); // Black color for wheel
        ourShader.use();
        glBindVertexArray(CVAO); // Assuming VAO for a cylinder
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        // Repeat for the other 3 wheels
        // Front Right Wheel
        translateMatrix = glm::translate(identityMatrix, glm::vec3(10.5f+dx, 20.0f , -18.8f + dx)); // Adjust z for right wheel
        model1 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model1);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        // Back Left Wheel
        translateMatrix = glm::translate(identityMatrix, glm::vec3(14.5f+dx , 20.0f, -18.8f + dx)); // Adjust x for back wheel
        model1 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model1);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        // Back Right Wheel
        translateMatrix = glm::translate(identityMatrix, glm::vec3(14.5f + dx, 20.0f + dx, -20.8f)); // Adjust x and z for back right wheel
        model1 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model1);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());


        
        if (flag == 1)
        {
            dx = dx + 0.1;
            if (dx >=47)
            {
                flag = 2;
            }
        }
        if (flag == 2)
        {
            dx = dx - 0.1;
            if (dx <= -2)
            {
                flag = 4;
            }
            
        }





        // street light lamp complete
        glm::mat4 modelMaku2 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(9.15, 14.0, 25.1));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.13f, 0.1f, 0.16f));
        modelMaku2 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku2);
        ourShader.setVec3("color", glm::vec3(0.722, 0.525, 0.043));
        ourShader.use();
        glBindVertexArray(CMVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 model2 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(9.15, 13.7, 25.1));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.33f, 0.3f, 0.8f));
        model2 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model2);
        ourShader.setVec3("color", glm::vec3(0.945, 0.769, 0.059));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        glm::mat4 modelMaku3 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.15, 14.0, 25.1));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.13f, 0.1f, 0.16f));
        modelMaku3 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku3);
        ourShader.setVec3("color", glm::vec3(0.722, 0.525, 0.043));
        ourShader.use();
        glBindVertexArray(CMVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 model3 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.15, 13.7, 25.1));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.33f, 0.3f, 0.8f));
        model3 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model3);
        ourShader.setVec3("color", glm::vec3(0.945, 0.769, 0.059));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        //stall1 wheel complete
        glm::mat4 model4 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(55.0, 0.48, -15.2));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.3f, 1.3f, 0.2f));
        model4 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model4);
        ourShader.setVec3("color", glm::vec3(0.58, 0.0, 0.827));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        translateMatrix = glm::translate(identityMatrix, glm::vec3(65.0, 0.48, -15.2));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.3f, 1.3f, 0.2f));
        model4 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model4);
        ourShader.setVec3("color", glm::vec3(0.58, 0.0, 0.827));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        translateMatrix = glm::translate(identityMatrix, glm::vec3(43.0, 0.48, -20.2));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.3f, 1.3f, 0.08f));
        model4 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model4);
        ourShader.setVec3("color", glm::vec3(0.58, 0.0, 0.827));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        glm::mat4 model5 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(21.2, -1.9, 8.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.2f, 0.2f, 2.8f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.55, 0.27, 0.07));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());


        // gach dandi complete
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-15, -1.9, 6.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.2f, 0.2f, 4.0f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.55, 0.27, 0.07));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        translateMatrix = glm::translate(identityMatrix, glm::vec3(20.5, -1.9, -12.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.2f, 0.2f, 4.0f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.55, 0.27, 0.07));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());
        translateMatrix = glm::translate(identityMatrix, glm::vec3(71.2, -1.9, 0.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.2f, 0.2f, 3.3f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.55, 0.27, 0.07));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());


        //gach er niche round
        translateMatrix = glm::translate(identityMatrix, glm::vec3(21.2, -2.5, 8.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.0f, 1.0f, 0.6f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.65, 0.16, 0.16));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        translateMatrix = glm::translate(identityMatrix, glm::vec3(71.2, -2.5, 0.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.50f, 1.50f, 0.6f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.65, 0.16, 0.16));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        translateMatrix = glm::translate(identityMatrix, glm::vec3(-15.0, -2.5, 6.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.50f, 1.50f, 0.6f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.65, 0.16, 0.16));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());


        translateMatrix = glm::translate(identityMatrix, glm::vec3(21.2, -2.5, -12.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(1.0f, 1.0f, 0.6f));
        model5 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model5);
        ourShader.setVec3("color", glm::vec3(0.65, 0.16, 0.16));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());



        //...................................skydriver Seat............................//
        

        glm::mat4 modelMaku111 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-3,1.3,-3));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.14f, 0.14f, 0.14f));
        modelMaku111 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku111);
        ourShader.setVec3("color", glm::vec3(1.0, 0.8, 0.9));
        ourShader.use();
        glBindVertexArray(CMVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 model111 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-3,1.7,-3));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
        model111 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model111);
        ourShader.setVec3("color", glm::vec3(1.0, 0.08, 0.58));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        glm::mat4 modelMaku112 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-1, 1.3, -3));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.14f, 0.14f, 0.14f));
        modelMaku112 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku112);
        ourShader.setVec3("color", glm::vec3(1.0, 0.8, 0.5));
        ourShader.use();
        glBindVertexArray(CMVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 model112 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-1, 1.7, -3));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
        model112 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model112);
        ourShader.setVec3("color", glm::vec3(1.0, 0.4, 0.0));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        glm::mat4 modelMaku113 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-1.5, 1.3, 0.5));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.14f, 0.14f, 0.14f));
        modelMaku113 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", modelMaku113);
        ourShader.setVec3("color", glm::vec3(0.7, 1.0, 0.85));
        ourShader.use();
        glBindVertexArray(CMVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, cylinderMaku.size());
        glm::mat4 model113 = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-1.5, 1.7, 0.5));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        scaleMatrix = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
        model113 = translateMatrix * rotateXMatrix * scaleMatrix;
        ourShader.setMat4("model", model113);
        ourShader.setVec3("color", glm::vec3(0.0, 0.8, 0.6));
        ourShader.use();
        glBindVertexArray(CVAO);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, cylinder.size());

        


        


        




        //.............. we now draw as many light bulbs as we have point lights.................//
        glBindVertexArray(lightCubeVAO);
        ourShader.use();
        for (unsigned int i = 0; i < 4; i++)
        { 
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions[i]);
            model = glm::scale(model, glm::vec3(0.5f,0.5f,0.5f)); // Make it a smaller cube
            ourShader.setMat4("model", model);
            ourShader.setVec3("color", glm::vec3(1.0f, 1.0f, 1.0f));
            
            glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
            
            
        }

        //.................................skyDrive stand................................//
        lightingShaderWithTexture.use();
        lightingShaderWithTexture.setVec3("viewPos", camera.Position);
        lightingShaderWithTexture.setMat4("projection", projection);
        lightingShaderWithTexture.setMat4("view", view);
        lightingShaderWithTexture.use();
        pointlight1.setUpPointLight(lightingShaderWithTexture);
        pointlight3.setUpPointLight(lightingShaderWithTexture);
        //pointlight4.setUpPointLight(lightingShaderWithTexture);
        pointlight5.setUpPointLight(lightingShaderWithTexture);



        stall1(cubeVAO, coffeeT,coffee,coffeT2, lightingShader, lightingShaderWithTexture, 0.0, 0.0, 0.0);


        //Drawing tree using fractiles
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-15.0, 0.0, 18.0));
        model = translateMatrix;
        drawTreeWithFractiles(cubeVAO, lightingShader, model, 0, 0, 0, 0);
        drawTreeWithFractiles1(cubeVAO, lightingShader, model, 0, 0, 0, 0);
        drawTreeWithFractiles2(cubeVAO, lightingShader, model, 0, 0, 0, 0);
        drawTreeWithFractiles3(cubeVAO, lightingShader, model, 0, 0, 0, 0);





        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        lightingShaderWithTexture.use();
        lightingShaderWithTexture.setVec3("viewPos", camera.Position);
        lightingShaderWithTexture.setMat4("projection", projection);
        lightingShaderWithTexture.setMat4("view", view);
        //2nd part of cube draw
        lightingShaderWithTexture.use();
        // point light 1
        pointlight1.setUpPointLight(lightingShaderWithTexture);
        // point light 3
        pointlight3.setUpPointLight(lightingShaderWithTexture);
        // point light 4
        pointlight4.setUpPointLight(lightingShaderWithTexture);


        // walls complete
        glm::mat4 modelMatrixForContainer = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-30.5, -2.5, -32.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(40, 12, 1.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        brick.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.0, -2.5, -32.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(50, 12, 1.0));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        brick.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-30.5, -2.5, -32.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(1.0, 12, 48));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        brick.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(83.0, -2.5, -32.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(1.0, 12, 48));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        brick.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);


        // grass surface complete
        modelMatrixForContainer = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-400.5, -2.6, -47.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(1100, .5, 700));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        water.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);

        // street lamp
        modelMatrixForContainer = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(9.0, -2.6, 15.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 20, 0.3));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(9.0, 17.4, 15.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 0.3, 10));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(9.0, 15.9, 25.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 1.8, 0.3));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);


        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.0, -2.6, 15.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 20, 0.3));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.0, 17.4, 15.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 0.3, 10));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(33.0, 15.9, 25.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.3, 1.8, 0.3));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        well.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);





        //road complete
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-43.5f + 13, -1.9f, 15.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 25));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(-18.5f + 13, -1.9f, 15.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 15));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(20.0f + 13, -1.9f, 15.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 17));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(36.5f + 13, -1.9f, 15.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 34));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(6.5f + 13, -1.9f, -32.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 28));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(20.0f + 13, -1.9f, -32.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 28));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(6.5f + 13, -1.9f, -5.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 31));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(20.0f + 13, -1.9f, -5.5f));// y=-2.0 for surface
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.001, 10, 31));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        road.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);

        //cone drawing .....................................
        glm::mat4 modelMatrixForGhostTail = glm::mat4(1.0f);
        modelMatrixForGhostTail = glm::translate(modelMatrixForGhostTail, glm::vec3(1.0f, -1.9f, -21.0f));
        modelMatrixForGhostTail = glm::scale(modelMatrixForGhostTail, glm::vec3(3.0f, 7.0f, 3.0f));
        modelMatrixForGhostTail = glm::rotate(modelMatrixForGhostTail, glm::radians(270.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        ghostTail.drawCone(lightingShaderWithTexture, modelMatrixForGhostTail, camera.Position);
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(1.0f, 5.3f, -18.6f))* glm::scale(identityMatrix, glm::vec3(1.0f, 1.0f, 1.0f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(0.0f, 5.3f, -19.0f))* glm::scale(identityMatrix, glm::vec3(1.0f, 1.0f, 1.0f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(-1.0f, 5.3f, -19.5f))* glm::scale(identityMatrix, glm::vec3(1.0f, 1.0f, 1.0f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(2.0f, 5.3f, -19.0f))* glm::scale(identityMatrix, glm::vec3(1.0f, 1.0f, 1.0f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(3.0f, 5.3f, -19.5f))* glm::scale(identityMatrix, glm::vec3(1.0f, 1.0f, 1.0f)));


        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(65.0f, 3.7f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(66.5f, 3.7f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(68.0f, 3.7f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(65.0f, 3.7f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(66.5f, 3.7f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(68.0f, 3.7f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.25, 0.28f, 0.25f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(65.0f, 4.4f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(66.5f, 4.4f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(68.0f, 4.4f, -16.0f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(65.0f, 4.4f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(66.5f, 4.4f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));
        sphere1.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(68.0f, 4.4f, -17.5f))* glm::scale(identityMatrix, glm::vec3(0.3f, 0.3f, 0.3f)));



        modelMatrixForContainer = glm::mat4(1.0f);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(64.0, 3.5, -19.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(5, .3, 4));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        sofa.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(57.0, 3.5, -19.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(5, .3, 4));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        sofa.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        translateMatrix = glm::translate(identityMatrix, glm::vec3(50.0, 3.5, -19.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(5, .3, 4));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        sofa.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(54.0f, 3.8f, -18.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(51.0f, 3.8f, -18.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(52.5f, 3.8f, -18.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(54.0f, 3.8f, -16.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(51.0f, 3.8f, -16.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));
        hsphere.drawHalfSphereWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(52.5f, 3.8f, -16.0f))* glm::scale(identityMatrix, glm::vec3(1.4f, 1.1f, 1.4f)));

        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(61.0f, 5.0f, -18.0f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(60.9, 3.5, -18.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 1.0, 0.0, 0.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(60.0f, 5.0f, -18.0f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(59.9, 3.5, -18.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 0.0, 1.0, 0.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(59.0f, 5.0f, -18.0f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(58.9, 3.5, -18.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 0.0, 0.0, 1.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(58.0f, 5.0f, -18.0f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(57.9, 3.5, -18.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 1.0, 1.0, 0.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(61.0f, 5.0f, -16.5f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(60.9, 3.5, -16.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 1.0, 0.0, 0.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(60.0f, 5.0f, -16.5f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(59.9, 3.5, -16.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 0.0, 1.0, 0.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(59.0f, 5.0f, -16.5f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(58.9, 3.5, -16.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 0.0, 0.0, 1.0);
        sphere.drawSphereWithTexture(lightingShaderWithTexture, glm::translate(identityMatrix, glm::vec3(58.0f, 5.0f, -16.5f))* glm::scale(identityMatrix, glm::vec3(0.8f, 0.8f, 0.8f)));
        translateMatrix = glm::translate(identityMatrix, glm::vec3(57.9, 3.5, -16.5));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(0.1, 1.5, 0.1));
        modelMatrixForContainer = translateMatrix * scaleMatrix;
        drawCube(cubeVAO, lightingShader, modelMatrixForContainer, 1.0, 1.0, 0.0);




        //menu
        translateMatrix = glm::translate(identityMatrix, glm::vec3(70.0, -1.9, -12.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(6, .3, 9));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(120.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        menu.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);

        translateMatrix = glm::translate(identityMatrix, glm::vec3(-12.0, -1.9, -13.0));
        scaleMatrix = glm::scale(identityMatrix, glm::vec3(6, .3, 9));
        rotateXMatrix = glm::rotate(identityMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        rotateYMatrix = glm::rotate(identityMatrix, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        rotateZMatrix = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        modelMatrixForContainer = translateMatrix * rotateXMatrix * rotateYMatrix * rotateZMatrix * scaleMatrix;
        menu2.drawCubeWithTexture(lightingShaderWithTexture, modelMatrixForContainer);


        //curve
        glm::mat4 modelMatrix = glm::mat4(1.0f);                 // Identity matrix
        modelMatrix = glm::translate(modelMatrix, glm::vec3(43.0f, 0.3f, 4.0f)); // Translate to (2, 1, -3)
        modelMatrix = glm::rotate(modelMatrix, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate 45 degrees around Y-axis
        modelMatrix = glm::scale(modelMatrix, glm::vec3(1.5));  // Uniformly scale by 1.5x
        myCurve.render(lightingShaderWithTexture, modelMatrix);

        glm::mat4 modelMatrix1 = glm::mat4(1.0f);                 // Identity matrix
        modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(21.0f, 5.0f, 15.0f)); // Translate to (2, 1, -3)
        modelMatrix1 = glm::rotate(modelMatrix1, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate 45 degrees around Y-axis
        modelMatrix1 = glm::scale(modelMatrix1, glm::vec3(1.5,5.0,1.5));  // Uniformly scale by 1.5x
        myCurve.render(lightingShaderWithTexture, modelMatrix1);

        glm::mat4 modelMatrix2 = glm::mat4(1.0f);                 // Identity matrix
        modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(21.0f, 5.0f, 20.0f)); // Translate to (2, 1, -3)
        modelMatrix2 = glm::rotate(modelMatrix2, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate 45 degrees around Y-axis
        modelMatrix2 = glm::scale(modelMatrix2, glm::vec3(1.5, 5.0, 1.5));  // Uniformly scale by 1.5x
        myCurve.render(lightingShaderWithTexture, modelMatrix2);

        glm::mat4 modelMatrix3 = glm::mat4(1.0f);                 // Identity matrix
        modelMatrix3 = glm::translate(modelMatrix3, glm::vec3(21.0f, 5.0f, 0.0f)); // Translate to (2, 1, -3)
        modelMatrix3 = glm::rotate(modelMatrix3, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate 45 degrees around Y-axis
        modelMatrix3 = glm::scale(modelMatrix3, glm::vec3(1.5, 5.0, 1.5));  // Uniformly scale by 1.5x
        myCurve.render(lightingShaderWithTexture, modelMatrix3);


        glm::mat4 modelMatrix4 = glm::mat4(1.0f);                 // Identity matrix
        modelMatrix4 = glm::translate(modelMatrix4, glm::vec3(37.0f, 8.0f, -25.0f)); // Translate to (2, 1, -3)
        modelMatrix4 = glm::rotate(modelMatrix4, glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate 45 degrees around Y-axis
        modelMatrix4 = glm::scale(modelMatrix4, glm::vec3(1.5, 7.0, 1.5));  // Uniformly scale by 1.5x
        myCurve.render(lightingShaderWithTexture, modelMatrix4);

        bash.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(-2.0f, -1.9f, -2.0f))* glm::scale(identityMatrix, glm::vec3(2,2,2)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(-8.0f, -1.9f, 2.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(-3.0f, -1.9f, 5.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(1.5f, -1.9f, 6.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(5.0f, -1.9f, 2.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(6.0f, -1.9f, -7.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(-8.0f, -1.9f, 2.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));
        hex.drawHexagonWithTexture(lightingShaderWithTexture, globalModel* glm::translate(identityMatrix, glm::vec3(-8.0f, -1.9f, 2.0f))* glm::scale(identityMatrix, glm::vec3(0.7, 1, 0.7)));









        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteVertexArrays(1, &lightCubeVAO);
    glDeleteBuffers(1, &cubeVBO);
    glDeleteBuffers(1, &cubeEBO);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}




// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        camera.ProcessKeyboard(FORWARD, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        camera.ProcessKeyboard(LEFT, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        camera.ProcessKeyboard(RIGHT, deltaTime);
    }

    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS)
    {
        flagDOLNA = 1;

    }
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS)
    {
        flagDOLNA = 0;

    }
    if (glfwGetKey(window, GLFW_KEY_I) == GLFW_PRESS) translate_Y += 0.001;
    if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS) translate_Y -= 0.001;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) translate_X += 0.001;
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS) translate_X -= 0.001;
    //if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) translate_Z += 0.001;
    //if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) translate_Z -= 0.001;
    if (glfwGetKey(window, GLFW_KEY_KP_1) == GLFW_PRESS)
    {
        pointlight1.turnOn();
        
    }

    if (glfwGetKey(window, GLFW_KEY_KP_2) == GLFW_PRESS)
    {
        pointlight1.turnOff();
    }
    if (glfwGetKey(window, GLFW_KEY_KP_3) == GLFW_PRESS)
    {
        pointlight3.turnOn();
    }

    if (glfwGetKey(window, GLFW_KEY_KP_4) == GLFW_PRESS)
    {
        pointlight3.turnOff();
    }
    if (glfwGetKey(window, GLFW_KEY_KP_5) == GLFW_PRESS)
    {
        pointlight4.turnOn();
    }

    if (glfwGetKey(window, GLFW_KEY_KP_6) == GLFW_PRESS)
    {
        pointlight4.turnOff();
    }
    if (glfwGetKey(window, GLFW_KEY_KP_7) == GLFW_PRESS)
    {
        pointlight5.turnOn();
    }

    if (glfwGetKey(window, GLFW_KEY_KP_8) == GLFW_PRESS)
    {
        pointlight5.turnOff();

    }

    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
    {
        nightflag = 1;
        pointlight1.turnOn();
        pointlight3.turnOn();

    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS )
    {
        nightflag = 2;
        pointlight1.turnOff();
        pointlight3.turnOff();

    }
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) scale_X += 0.001;

    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
    {
        rotateAngle_X += 0.1;
        rotateAxis_X = 1.0;
        rotateAxis_Y = 0.0;
        rotateAxis_Z = 0.0;
    }
    if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS)
    {
        flagR = 5;
        
    }



    if (glfwGetKey(window, GLFW_KEY_Y) == GLFW_PRESS)
    {
        rotateAngle_Y += 0.1;
        rotateAxis_X = 0.0;
        rotateAxis_Y = 1.0;
        rotateAxis_Z = 0.0;
    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        camera.ProcessKeyboard(FORWARD, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        camera.ProcessKeyboard(LEFT, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        camera.ProcessKeyboard(RIGHT, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        camera.ProcessKeyboard(UP, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
        camera.ProcessKeyboard(DOWN, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
        camera.ProcessKeyboard(P_UP, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) {
        camera.ProcessKeyboard(P_DOWN, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_Y) == GLFW_PRESS) {
        camera.ProcessKeyboard(Y_LEFT, deltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_V) == GLFW_PRESS) {
        camera.ProcessKeyboard(Y_RIGHT, deltaTime);
    }
    /*if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
        camera.ProcessKeyboard(R_LEFT, deltaTime);
    }*/
    if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
        flagRocket = 1;
    }
    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {
        flagRocket = 0;
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        camera.ProcessKeyboard(R_RIGHT, deltaTime);
    }
    
    ///new add
    if (glfwGetKey(window, GLFW_KEY_V) == GLFW_PRESS)
    {
        
        pointlight4.turnOn();
        cout << "on" << endl;
    }
    //newadddd
    if (glfwGetKey(window, GLFW_KEY_7) == GLFW_PRESS)
    {
        pointlight1.turnDiffuseOn();
        pointlight3.turnDiffuseOn();
        spotLight.turnDiffuseOn();
        dirLight.turnDiffuseOn();

    }
    if (glfwGetKey(window, GLFW_KEY_8) == GLFW_PRESS)
    {
        
        pointlight1.turnOff();
        pointlight3.turnOff();
        dirLight.turnOff();
        spotLight.turnOff();

    }
    if (glfwGetKey(window, GLFW_KEY_M) == GLFW_PRESS)
    {
        flag = 1.00;

    }
    if (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS)
    {
        flagSD = 1;

    }

    if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS)
    {
        dirLight.turnOn();

    }
    if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS)
    {
        dirLight.turnOff();
    }
    if (glfwGetKey(window, GLFW_KEY_5) == GLFW_PRESS)
    {
        spotLight.turnOn();

    }
    if (glfwGetKey(window, GLFW_KEY_6) == GLFW_PRESS)
    {
        spotLight.turnOff();
    }
    if (glfwGetKey(window, GLFW_KEY_9) == GLFW_PRESS)
    {
        pointlight1.turnAmbientOn();
        pointlight3.turnAmbientOn();
        spotLight.turnAmbientOn();
        dirLight.turnAmbientOn();
    }
    if (glfwGetKey(window, GLFW_KEY_0) == GLFW_PRESS)
    {
        pointlight1.turnSpecularOn();
        pointlight3.turnSpecularOn();
        spotLight.turnSpecularOn();
        dirLight.turnSpecularOn();
    }


 
    


}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);  // H & J
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);

    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(static_cast<float>(yoffset));
}
unsigned int loadTexture(char const* path, GLenum textureWrappingModeS, GLenum textureWrappingModeT, GLenum textureFilteringModeMin, GLenum textureFilteringModeMax)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);

        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, textureWrappingModeS);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, textureWrappingModeT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, textureFilteringModeMin);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, textureFilteringModeMax);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}



void stall1(unsigned int& cubeVAO, Cube& coffee, Cube& coffee1, Cube& coffee2, Shader& lightingShader, Shader& lightingShaderWithTexture, float txC, float tyC, float tzC)
{
    glm::mat4 translateMatrix, rotateXMatrix, rotateYMatrix, rotateZMatrix, scaleMatrix, modelLathi;
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(50.0, -0.5, -25.0, 0.0, 0.0, 0.0, 20.0f, 8.0f, 1.0f);
    drawCube(cubeVAO, lightingShader, modelLathi, 1,1,1);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(50.0, -0.5, -20.0, 0.0, 0.0, 0.0, 20.0f, 4.00f, 5.0f);
    coffee.drawCubeWithTexture(lightingShaderWithTexture, modelLathi);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(50.0, 7.0 , -25.00, 0.0, 0.0, 0.0, 20.0f, 0.50f, 10.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(50.0, -0.5, -25.0, 0.0, -90.0, 0.0, 10.0f, 8.0f, 0.50f);
    coffee.drawCubeWithTexture(lightingShaderWithTexture, modelLathi);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(70.0, -0.5, -25.0, 0.0, -90.0, 0.0, 10.0f, 8.00f, 0.50f);
    coffee.drawCubeWithTexture(lightingShaderWithTexture, modelLathi);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(51.0, 7.0, -16.0, 0.0, 0.0, 0.0, 17.00f, 4.00f, 0.50f);
    coffee2.drawCubeWithTexture(lightingShaderWithTexture, modelLathi);


    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(48.0, -1.9, -3.0, 0.0, -90.0, 0.0, 10.0f, 3.5f, 8.0f);
    coffee1.drawCubeWithTexture(lightingShaderWithTexture, modelLathi);

    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9 + 1.5, 1.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9, 2.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9, 4.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9 + 1.5, -5.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9, -4.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(38.0, -1.9, -2.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);


    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9 + 1.5, 1.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9, 2.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9, 4.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9 + 1.5, -5.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9, -4.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(52.0, -1.9, -2.0 + 1.00 + 1.00, 0.0, -90.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = transform(45.5, -1.9 + 1.5, 9.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(42.0, -1.9, 9.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(45.0, -1.9, 9.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = transform(45.5, -1.9 + 1.5, -7.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 4.50f, 0.50f, 2.0f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(42.0, -1.9, -7.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(45.0, -1.9, -7.0 + 1.00 + 1.00, 0.0, 180.0, 0.0, 0.50f, 2.00f, 2.00f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);

    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(43.0, -1.9, -20.1, 0.0, 0.0, 0.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(44.8, -1.0, -20.1, 0.0, 0.0, 55.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(45.0, 1.3, -20.1, 0.0, 0.0, 120.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);


    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(55.0, -1.9, -14.9, 0.0, 0.0, 0.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(56.8, -1.0, -14.9, 0.0, 0.0, 55.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(57.1, 1.4, -14.9, 0.0, 0.0, 120.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);

    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(65.0, -1.9, -14.9, 0.0, 0.0, 0.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(66.8, -1.0, -14.9, 0.0, 0.0, 55.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(67.1, 1.4, -14.9, 0.0, 0.0, 120.0, 0.25f, 4.7f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);

    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(49.2, 2.0, -20.2, 0.0, 0.0, 90.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(45.0, 3.5, -21.6, 90.0, 0.0, 0.0, 0.25f, 2.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);
    modelLathi = transform(47.8, 0.1, -21.6, 90.0, 0.0, 0.0, 0.25f, 2.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 1.0f);

    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(45.0, 2.0, -20.1, 0.0, 0.0, 0.0, 0.25f, 1.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 0.50f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(47.8, 0.0, -20.2, 0.0, 0.0, -55.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 0.5f);
    modelLathi = glm::mat4(1.0f);
    modelLathi = transform(44.4, 2.6, -20.2, 0.0, 0.0, -125.0, 0.25f, 4.5f, 0.08f);
    lightingShader.setMat4("model", modelLathi);
    drawCube(cubeVAO, lightingShader, modelLathi, 0.9f, 0.50f, 0.5f);



}


void drawTreeWithFractiles(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N)
{
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 translate = glm::mat4(1.0f);
    glm::mat4 identityMatrix = glm::mat4(1.0f);
    glm::mat4 scale = glm::mat4(1.0f);
    glm::mat4 next = glm::mat4(1.0f);
    glm::mat4 rotate = glm::mat4(1.0f);
    if (N == 0) {
        float length = 0.8;
        float height = 6.0;
        float width = 0.5;
        float mvx = length * 0.05;
        float mvy = height - height * 0.1;
        float mvz = width * 0.05;
        translate = glm::translate(identityMatrix, glm::vec3(36,2.5,-10));
        next = translate * alTogether;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N > 0 && N < 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        float mvx = length * 0.3 + height * 0.7071;
        float mvy = height * 0.7071;
        float mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 - height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3 - height * 0.7071;
        mvy = height * 0.7071;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 + height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N == 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
    }

}

void drawTreeWithFractiles1(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N)
{
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 translate = glm::mat4(1.0f);
    glm::mat4 identityMatrix = glm::mat4(1.0f);
    glm::mat4 scale = glm::mat4(1.0f);
    glm::mat4 next = glm::mat4(1.0f);
    glm::mat4 rotate = glm::mat4(1.0f);
    if (N == 0) {
        float length = 0.8;
        float height = 6.0;
        float width = 0.5;
        float mvx = length * 0.05;
        float mvy = height - height * 0.1;
        float mvz = width * 0.05;
        translate = glm::translate(identityMatrix, glm::vec3(35, 5.5, -30));
        next = translate * alTogether;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N > 0 && N < 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        float mvx = length * 0.3 + height * 0.7071;
        float mvy = height * 0.7071;
        float mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 - height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3 - height * 0.7071;
        mvy = height * 0.7071;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 + height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles1(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N == 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
    }

}

void drawTreeWithFractiles2(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N)
{
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 translate = glm::mat4(1.0f);
    glm::mat4 identityMatrix = glm::mat4(1.0f);
    glm::mat4 scale = glm::mat4(1.0f);
    glm::mat4 next = glm::mat4(1.0f);
    glm::mat4 rotate = glm::mat4(1.0f);
    if (N == 0) {
        float length = 0.8;
        float height = 6.0;
        float width = 0.5;
        float mvx = length * 0.05;
        float mvy = height - height * 0.1;
        float mvz = width * 0.05;
        translate = glm::translate(identityMatrix, glm::vec3(86, 3.8, -18));
        next = translate * alTogether;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N > 0 && N < 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        float mvx = length * 0.3 + height * 0.7071;
        float mvy = height * 0.7071;
        float mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 - height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3 - height * 0.7071;
        mvy = height * 0.7071;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 + height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles2(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N == 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
    }

}

void drawTreeWithFractiles3(unsigned int& cubeVAO, Shader& lightingShader, glm::mat4 alTogether, float L, float H, float W, int N)
{
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 translate = glm::mat4(1.0f);
    glm::mat4 identityMatrix = glm::mat4(1.0f);
    glm::mat4 scale = glm::mat4(1.0f);
    glm::mat4 next = glm::mat4(1.0f);
    glm::mat4 rotate = glm::mat4(1.0f);
    if (N == 0) {
        float length = 0.8;
        float height = 6.0;
        float width = 0.5;
        float mvx = length * 0.05;
        float mvy = height - height * 0.1;
        float mvz = width * 0.05;
        translate = glm::translate(identityMatrix, glm::vec3(0, 5, -12.0));
        next = translate * alTogether;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N > 0 && N < 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.56, 0.93, 0.56);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.5, 0.0);
        float mvx = length * 0.3 + height * 0.7071;
        float mvy = height * 0.7071;
        float mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 - height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3 - height * 0.7071;
        mvy = height * 0.7071;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height * 0.7071;
        mvz = width * 0.3 + height * 0.7071;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
        mvx = length * 0.3;
        mvy = height;
        mvz = width * 0.3;
        translate = glm::translate(identityMatrix, glm::vec3(mvx, mvy, mvz));
        next = translate * alTogether;
        drawTreeWithFractiles3(cubeVAO, lightingShader, next, length, height, width, N + 1);
    }
    else if (N == 4) {
        float length = L * 0.6;
        float height = H * 0.6;
        float width = W * 0.6;
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(-45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        rotate = glm::rotate(identityMatrix, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = alTogether * rotate * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
        scale = glm::scale(identityMatrix, glm::vec3(length, height, width));
        model = alTogether * scale;
        drawCube(cubeVAO, lightingShader, model, 0.0, 0.95, 0.1);
    }

}

