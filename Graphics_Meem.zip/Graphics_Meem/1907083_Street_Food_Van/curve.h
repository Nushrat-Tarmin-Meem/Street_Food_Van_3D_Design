#ifndef CURVE_H
#define CURVE_H

#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <fstream>
#include <vector>
#include <iostream>
#include <string>
#include "shader.h"

class Curve {
public:
    // Constructor
    Curve(const std::string& vertexFilePath, const std::string& indexFilePath, glm::vec3 a = glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3 d = glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3 spec = glm::vec3(1.0f, 1.0f, 1.0f), float sh = 32.0f, glm::vec3 e = glm::vec3(1.0f, 1.0f, 1.0f))
    {
        this->ambientt = a;
        this->diffusee = d;
        this->specularr = spec;
        this->shinyness = sh;
        this->emission = e;
        loadVertices(vertexFilePath);
        loadIndices(indexFilePath);
        setupVAO();
    }

    // Destructor
    ~Curve()
    {
        glDeleteVertexArrays(1, &VAO);
        glDeleteBuffers(1, &VBO);
        glDeleteBuffers(1, &EBO);
    }

    // Render the curve
    void render(Shader& shader, const glm::mat4& model)
    {
        //, const glm::mat4& view, const glm::mat4& projection, const glm::vec3& lightPos, const glm::vec3& viewPos
        shader.use();

        // Set transformation matrices
        shader.setMat4("model", model);
        // shader.setMat4("view", view);
         //shader.setMat4("projection", projection);

         // Set material properties
         /*
         *      shader.setVec3("material.ambient", glm::vec3(0.2f, 0.2f, 0.2f));
         shader.setVec3("material.diffuse", glm::vec3(0.5f, 0.5f, 0.5f));
         shader.setVec3("material.specular", glm::vec3(1.0f, 1.0f, 1.0f));
         shader.setFloat("material.shininess", 32.0f);
         shader.setVec3("material.emission", glm::vec3(0.0f, 0.0f, 0.0f));
         */
        shader.setVec3("material.ambient", ambientt);
        shader.setVec3("material.diffuse", diffusee);
        shader.setVec3("material.specular", specularr);
        shader.setFloat("material.shininess", shinyness);
        shader.setVec3("material.emission", emission);

        // Set light and camera positions
        //shader.setVec3("viewPos", viewPos);

        // Assuming you have point lights configured in your shader, set at least one light:
        //shader.setVec3("pointLights[0].position", lightPos);
        /*
        *     shader.setVec3("ambient", glm::vec3(0.1f, 0.1f, 0.1f));
        shader.setVec3("diffuse", glm::vec3(0.8f, 0.8f, 0.8f));
        shader.setVec3("specular", glm::vec3(1.0f, 1.0f, 1.0f));
        shader.setFloat("pointLights[0].k_c", 1.0f);
        shader.setFloat("pointLights[0].k_l", 0.09f);
        shader.setFloat("pointLights[0].k_q", 0.032f);

        */

        // Bind VAO and render
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }

private:
    unsigned int VAO, VBO, EBO;
    std::vector<float> vertices;  // x, y, z, nx, ny, nz
    std::vector<unsigned int> indices;
    glm::vec3 ambientt, diffusee, specularr, emission;
    float shinyness;

    // Load vertices from the text file
    void loadVertices(const std::string& filePath)
    {
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cerr << "Error: Unable to open vertices file: " << filePath << std::endl;
            return;
        }

        float x, y, z, nx, ny, nz;
        while (file >> x >> y >> z >> nx >> ny >> nz) {
            vertices.push_back(x);
            vertices.push_back(y);
            vertices.push_back(z);
            vertices.push_back(nx);
            vertices.push_back(ny);
            vertices.push_back(nz);
        }
        file.close();
    }

    // Load indices from the text file
    void loadIndices(const std::string& filePath)
    {
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cerr << "Error: Unable to open indices file: " << filePath << std::endl;
            return;
        }

        unsigned int i1, i2, i3;
        while (file >> i1 >> i2 >> i3) {
            indices.push_back(i1);
            indices.push_back(i2);
            indices.push_back(i3);
        }
        file.close();
    }

    // Set up the VAO, VBO, and EBO
    void setupVAO()
    {
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glGenBuffers(1, &EBO);

        glBindVertexArray(VAO);

        // Load vertex data into VBO
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

        // Load index data into EBO
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

        // Set vertex attribute pointers
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0); // Position
        glEnableVertexAttribArray(0);

        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float))); // Normal
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }
};

#endif // CURVE_H